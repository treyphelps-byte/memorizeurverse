import {
  users,
  verses,
  devotions,
  practiceSessions,
  userProgress,
  achievements,
  userAchievements,
  favoriteDevotions,
  readDevotions,
  type User,
  type UpsertUser,
  type Verse,
  type InsertVerse,
  type Devotion,
  type InsertDevotion,
  type PracticeSession,
  type InsertPracticeSession,
  type UserProgress,
  type InsertUserProgress,
  type Achievement,
  type InsertAchievement,
  type UserAchievement,
  type InsertUserAchievement,
  type FavoriteDevotion,
  type InsertFavoriteDevotion,
  type ReadDevotion,
  type InsertReadDevotion,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Verse operations
  getAllVerses(): Promise<Verse[]>;
  getVerse(id: string): Promise<Verse | undefined>;
  createVerse(verse: InsertVerse): Promise<Verse>;
  
  // Devotion operations
  getAllDevotions(userId: string): Promise<any[]>;
  getDevotion(id: string): Promise<Devotion | undefined>;
  createDevotion(devotion: InsertDevotion): Promise<Devotion>;
  
  // Practice session operations
  createPracticeSession(session: InsertPracticeSession): Promise<PracticeSession>;
  getUserPracticeSessions(userId: string): Promise<PracticeSession[]>;
  
  // User progress operations
  getUserProgress(userId: string): Promise<UserProgress | undefined>;
  updateUserProgress(userId: string, updates: Partial<InsertUserProgress>): Promise<UserProgress>;
  
  // Achievement operations
  getAllAchievements(): Promise<Achievement[]>;
  getUserAchievements(userId: string): Promise<(UserAchievement & { achievement: Achievement })[]>;
  unlockAchievement(userAchievement: InsertUserAchievement): Promise<UserAchievement>;
  
  // Favorite devotions
  addFavoriteDevotion(favorite: InsertFavoriteDevotion): Promise<FavoriteDevotion>;
  removeFavoriteDevotion(userId: string, devotionId: string): Promise<void>;
  getUserFavoriteDevotions(userId: string): Promise<FavoriteDevotion[]>;
  
  // Read devotions
  markDevotionAsRead(read: InsertReadDevotion): Promise<ReadDevotion>;
  getUserReadDevotions(userId: string): Promise<ReadDevotion[]>;
  
  // Leaderboard
  getLeaderboard(limit?: number): Promise<any[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    
    // Initialize user progress if not exists
    await db
      .insert(userProgress)
      .values({ userId: user.id })
      .onConflictDoNothing();
    
    return user;
  }

  // Verse operations
  async getAllVerses(): Promise<Verse[]> {
    return await db.select().from(verses);
  }

  async getVerse(id: string): Promise<Verse | undefined> {
    const [verse] = await db.select().from(verses).where(eq(verses.id, id));
    return verse;
  }

  async createVerse(verseData: InsertVerse): Promise<Verse> {
    const [verse] = await db
      .insert(verses)
      .values(verseData)
      .returning();
    return verse;
  }

  // Devotion operations
  async getAllDevotions(userId: string): Promise<any[]> {
    const allDevotions = await db.select().from(devotions).orderBy(desc(devotions.date));
    const favorites = await this.getUserFavoriteDevotions(userId);
    const readList = await this.getUserReadDevotions(userId);
    
    const favoriteIds = new Set(favorites.map(f => f.devotionId));
    const readIds = new Set(readList.map(r => r.devotionId));
    
    return allDevotions.map(d => ({
      ...d,
      isFavorite: favoriteIds.has(d.id),
      isRead: readIds.has(d.id),
    }));
  }

  async getDevotion(id: string): Promise<Devotion | undefined> {
    const [devotion] = await db.select().from(devotions).where(eq(devotions.id, id));
    return devotion;
  }

  async createDevotion(devotionData: InsertDevotion): Promise<Devotion> {
    const [devotion] = await db
      .insert(devotions)
      .values(devotionData)
      .returning();
    return devotion;
  }

  // Practice session operations
  async createPracticeSession(sessionData: InsertPracticeSession): Promise<PracticeSession> {
    const [session] = await db
      .insert(practiceSessions)
      .values(sessionData)
      .returning();
    return session;
  }

  async getUserPracticeSessions(userId: string): Promise<PracticeSession[]> {
    return await db
      .select()
      .from(practiceSessions)
      .where(eq(practiceSessions.userId, userId))
      .orderBy(desc(practiceSessions.completedAt));
  }

  // User progress operations
  async getUserProgress(userId: string): Promise<UserProgress | undefined> {
    const [progress] = await db
      .select()
      .from(userProgress)
      .where(eq(userProgress.userId, userId));
    return progress;
  }

  async updateUserProgress(userId: string, updates: Partial<InsertUserProgress>): Promise<UserProgress> {
    const [progress] = await db
      .update(userProgress)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(userProgress.userId, userId))
      .returning();
    return progress;
  }

  // Achievement operations
  async getAllAchievements(): Promise<Achievement[]> {
    return await db.select().from(achievements);
  }

  async getUserAchievements(userId: string): Promise<(UserAchievement & { achievement: Achievement })[]> {
    const results = await db
      .select()
      .from(userAchievements)
      .innerJoin(achievements, eq(userAchievements.achievementId, achievements.id))
      .where(eq(userAchievements.userId, userId));
    
    return results.map(r => ({
      ...r.user_achievements,
      achievement: r.achievements,
    }));
  }

  async unlockAchievement(userAchievementData: InsertUserAchievement): Promise<UserAchievement> {
    const [userAchievement] = await db
      .insert(userAchievements)
      .values(userAchievementData)
      .onConflictDoNothing()
      .returning();
    return userAchievement;
  }

  // Favorite devotions
  async addFavoriteDevotion(favoriteData: InsertFavoriteDevotion): Promise<FavoriteDevotion> {
    const [favorite] = await db
      .insert(favoriteDevotions)
      .values(favoriteData)
      .returning();
    return favorite;
  }

  async removeFavoriteDevotion(userId: string, devotionId: string): Promise<void> {
    await db
      .delete(favoriteDevotions)
      .where(
        and(
          eq(favoriteDevotions.userId, userId),
          eq(favoriteDevotions.devotionId, devotionId)
        )
      );
  }

  async getUserFavoriteDevotions(userId: string): Promise<FavoriteDevotion[]> {
    return await db
      .select()
      .from(favoriteDevotions)
      .where(eq(favoriteDevotions.userId, userId));
  }

  // Read devotions
  async markDevotionAsRead(readData: InsertReadDevotion): Promise<ReadDevotion> {
    const [read] = await db
      .insert(readDevotions)
      .values(readData)
      .onConflictDoNothing()
      .returning();
    return read;
  }

  async getUserReadDevotions(userId: string): Promise<ReadDevotion[]> {
    return await db
      .select()
      .from(readDevotions)
      .where(eq(readDevotions.userId, userId));
  }

  // Leaderboard
  async getLeaderboard(limit: number = 100): Promise<any[]> {
    const results = await db
      .select()
      .from(userProgress)
      .innerJoin(users, eq(userProgress.userId, users.id))
      .orderBy(desc(userProgress.totalPoints))
      .limit(limit);
    
    return results.map((r, index) => ({
      user: r.users,
      progress: r.user_progress,
      rank: index + 1,
    }));
  }
}

export const storage = new DatabaseStorage();
