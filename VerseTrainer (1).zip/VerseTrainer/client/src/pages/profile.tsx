import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { BookOpen, Flame, TrendingUp, Award, Lock } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import firstVerseIcon from "@assets/generated_images/First_verse_scroll_badge_icon_07a77c18.png";
import sevenDayIcon from "@assets/generated_images/Seven_day_streak_flame_badge_9c86194f.png";
import hundredVersesIcon from "@assets/generated_images/One_hundred_verses_trophy_badge_84f2c8cd.png";
import perfectAccuracyIcon from "@assets/generated_images/Perfect_accuracy_star_badge_icon_87388730.png";
import type { UserProgress, Achievement, UserAchievement } from "@shared/schema";

export default function Profile() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: progress, isLoading: progressLoading } = useQuery<UserProgress>({
    queryKey: ["/api/progress"],
  });

  const { data: allAchievements, isLoading: achievementsLoading } = useQuery<Achievement[]>({
    queryKey: ["/api/achievements"],
  });

  const { data: unlockedAchievements } = useQuery<(UserAchievement & { achievement: Achievement })[]>({
    queryKey: ["/api/achievements/unlocked"],
  });

  const unlockedIds = new Set(unlockedAchievements?.map(ua => ua.achievementId) || []);

  const getAchievementImage = (iconType: string) => {
    switch (iconType) {
      case "scroll":
        return firstVerseIcon;
      case "flame":
        return sevenDayIcon;
      case "trophy":
        return hundredVersesIcon;
      case "star":
        return perfectAccuracyIcon;
      default:
        return firstVerseIcon;
    }
  };

  if (authLoading || progressLoading || achievementsLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 container max-w-6xl px-4 py-8">
          <div className="space-y-8">
            <Skeleton className="h-32 w-full" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Skeleton className="h-40" />
              <Skeleton className="h-40" />
              <Skeleton className="h-40" />
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 container max-w-6xl px-4 py-8">
        <div className="space-y-8">
          {/* Profile Header */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row items-center gap-6">
                <Avatar className="h-24 w-24 ring-2 ring-primary">
                  <AvatarImage src={user?.profileImageUrl || undefined} style={{ objectFit: 'cover' }} />
                  <AvatarFallback className="text-2xl">
                    {user?.firstName?.[0] || user?.email?.[0] || "U"}
                  </AvatarFallback>
                </Avatar>
                <div className="text-center md:text-left flex-1">
                  <h1 className="text-3xl font-serif font-bold">
                    {user?.firstName && user?.lastName
                      ? `${user.firstName} ${user.lastName}`
                      : user?.firstName || user?.email || "User"}
                  </h1>
                  {user?.email && (
                    <p className="text-muted-foreground">{user.email}</p>
                  )}
                  <div className="flex flex-wrap gap-4 mt-4 justify-center md:justify-start">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-primary">
                        {progress?.totalVersesPracticed || 0}
                      </div>
                      <div className="text-sm text-muted-foreground">Verses</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-chart-2">
                        {progress?.currentStreak || 0}
                      </div>
                      <div className="text-sm text-muted-foreground">Day Streak</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-chart-5">
                        {progress?.totalPoints || 0}
                      </div>
                      <div className="text-sm text-muted-foreground">Points</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Verses Practiced
                </CardTitle>
                <BookOpen className="h-5 w-5 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{progress?.totalVersesPracticed || 0}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  Keep practicing to grow your knowledge
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Current Streak
                </CardTitle>
                <Flame className="h-5 w-5 text-chart-2" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{progress?.currentStreak || 0} days</div>
                <p className="text-xs text-muted-foreground mt-1">
                  Longest: {progress?.longestStreak || 0} days
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Points
                </CardTitle>
                <TrendingUp className="h-5 w-5 text-chart-5" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{progress?.totalPoints || 0}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  Earn points by practicing verses
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Achievements */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Award className="h-5 w-5 text-primary" />
                <CardTitle>Achievements</CardTitle>
              </div>
              <CardDescription>
                Unlock badges by reaching milestones
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {allAchievements?.map((achievement) => {
                  const isUnlocked = unlockedIds.has(achievement.id);
                  return (
                    <div
                      key={achievement.id}
                      className={`flex flex-col items-center gap-3 p-4 rounded-lg border transition-all ${
                        isUnlocked
                          ? "bg-card hover-elevate"
                          : "opacity-50 grayscale"
                      }`}
                      data-testid={`achievement-${achievement.id}`}
                    >
                      <div className="relative">
                        <img
                          src={getAchievementImage(achievement.iconType)}
                          alt={achievement.name}
                          className="w-16 h-16 object-contain"
                        />
                        {!isUnlocked && (
                          <div className="absolute inset-0 flex items-center justify-center bg-background/80 rounded-full">
                            <Lock className="h-6 w-6 text-muted-foreground" />
                          </div>
                        )}
                      </div>
                      <div className="text-center">
                        <div className="font-semibold text-sm">{achievement.name}</div>
                        <div className="text-xs text-muted-foreground mt-1">
                          {achievement.description}
                        </div>
                        {!isUnlocked && (
                          <div className="mt-2">
                            <Progress
                              value={calculateProgress(achievement, progress)}
                              className="h-1"
                            />
                            <p className="text-xs text-muted-foreground mt-1">
                              {getProgressText(achievement, progress)}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
}

function calculateProgress(achievement: Achievement, progress?: UserProgress): number {
  if (!progress) return 0;
  
  let current = 0;
  switch (achievement.category) {
    case "verses":
      current = progress.totalVersesPracticed;
      break;
    case "streak":
      current = progress.currentStreak;
      break;
    case "accuracy":
      current = 100; // This would need to track average accuracy
      break;
  }
  
  return Math.min((current / achievement.requirement) * 100, 100);
}

function getProgressText(achievement: Achievement, progress?: UserProgress): string {
  if (!progress) return `0 / ${achievement.requirement}`;
  
  let current = 0;
  switch (achievement.category) {
    case "verses":
      current = progress.totalVersesPracticed;
      break;
    case "streak":
      current = progress.currentStreak;
      break;
    case "accuracy":
      current = 100;
      break;
  }
  
  return `${current} / ${achievement.requirement}`;
}
