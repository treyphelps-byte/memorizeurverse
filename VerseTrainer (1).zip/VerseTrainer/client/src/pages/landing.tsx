import { useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BookOpen, Mic, Trophy, Calendar, TrendingUp, Award } from "lucide-react";
import { Footer } from "@/components/Footer";
import { useAuth } from "@/hooks/useAuth";
import heroImage from "@assets/generated_images/Peaceful_sunrise_mountain_landscape_b04051e1.png";

export default function Landing() {
  const { isAuthenticated, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && isAuthenticated) {
      setLocation("/home");
    }
  }, [isAuthenticated, isLoading, setLocation]);

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section */}
      <section
        className="relative min-h-[600px] flex items-center justify-center text-center px-4"
        style={{
          backgroundImage: `linear-gradient(to bottom, rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.6)), url(${heroImage})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="max-w-4xl space-y-6">
          <h1 className="text-5xl md:text-6xl font-serif font-bold text-white">
            Memorize Scripture.<br />Grow in Faith.
          </h1>
          <p className="text-xl md:text-2xl text-white/90 leading-relaxed">
            Join thousands memorizing Bible verses daily with speech recognition,
            gamification, and daily devotions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Button
              size="lg"
              className="text-lg backdrop-blur-sm bg-primary/90 hover:bg-primary border border-primary-border"
              onClick={() => window.location.href = "/api/login"}
              data-testid="button-get-started"
            >
              <BookOpen className="mr-2 h-5 w-5" />
              Get Started Free
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-lg backdrop-blur-sm bg-background/20 hover:bg-background/30 text-white border-white/40"
              onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
              data-testid="button-learn-more"
            >
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16 md:py-24 px-4">
        <div className="container max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">
              Everything You Need to Memorize Scripture
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Powerful features designed to make Bible memorization engaging, effective, and rewarding.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Mic className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Speech Recognition</CardTitle>
                <CardDescription>
                  Practice verses by speaking them aloud. Get instant feedback with color-coded word highlighting.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <TrendingUp className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Progress Tracking</CardTitle>
                <CardDescription>
                  Track verses practiced, accuracy percentage, and maintain daily streaks to stay motivated.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Award className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Achievements & Badges</CardTitle>
                <CardDescription>
                  Unlock achievements and earn badges as you reach milestones in your memorization journey.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Calendar className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Daily Devotions</CardTitle>
                <CardDescription>
                  Read short daily devotionals with scripture references and reflections to deepen your faith.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Trophy className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Leaderboard</CardTitle>
                <CardDescription>
                  Compete with other believers and see where you rank on the global leaderboard.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <BookOpen className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Verse Library</CardTitle>
                <CardDescription>
                  Choose from curated verses or add your own. Organize by categories like Hope, Faith, and Love.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-primary/5">
        <div className="container max-w-4xl px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-primary mb-2">10,000+</div>
              <div className="text-muted-foreground">Active Users</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">500,000+</div>
              <div className="text-muted-foreground">Verses Practiced</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">95%</div>
              <div className="text-muted-foreground">Retention Rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 px-4">
        <div className="container max-w-3xl text-center">
          <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">
            Start Your Journey Today
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Join thousands of believers memorizing Scripture and growing in their faith.
          </p>
          <Button
            size="lg"
            className="text-lg"
            onClick={() => window.location.href = "/api/login"}
            data-testid="button-cta-signup"
          >
            <BookOpen className="mr-2 h-5 w-5" />
            Sign Up Free
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  );
}
